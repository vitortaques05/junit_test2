package com.mycompany.projetoteste;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class ReservaPassagensTest {

    @Test
    public void testRealizarCheckIn() {
        ReservaPassagens reserva = criarReservaPadrao();
        assertTrue(reserva.isCheckInRealizado());
        assertFalse(reserva.isCheckInRealizado()); // Verificar que o check-in não pode ser realizado novamente
    }

    @Test
    public void testCancelarReserva() {
        ReservaPassagens reserva = criarReservaPadrao();
        reserva.realizaReserva(reserva); // Realizar uma reserva antes de cancelar (para ter algo a cancelar)
        reserva.cancelarReserva();
        assertEquals(10, reserva.getVoo().getAssentosDisponiveis()); // Verificar se os assentos foram liberados corretamente
    }

    @Test
    public void testRealizaReservaComSucesso() {
        ReservaPassagens reserva = criarReservaPadrao();
        ReservaPassagens reserva2 = new ReservaPassagens("Origem2", "Destino2", new Date(), 2, reserva.getVoo());
        reserva.realizaReserva(reserva2);
        assertEquals(8, reserva.getVoo().getAssentosDisponiveis()); // Verificar se os assentos foram reservados corretamente
    }

    @Test
    public void testRealizaReservaSemAssentosDisponiveis() {
   // Configuração do cenário de teste
        ReservaPassagens reserva = criarReservaPadrao();
        reserva.getVoo().setAssentosDisponiveis(0);  // Voo sem assentos disponíveis

        // Execução do método que tenta realizar a reserva
        reserva.realizaReserva(reserva);

        // Verificação do resultado esperado
        assertFalse(reserva.isCheckInRealizado());  // O check-in não deve ser realizado
    }

    private ReservaPassagens criarReservaPadrao() {
        ReservaPassagens reserva = new ReservaPassagens("Origem", "Destino", new Date(), 2, null);
        reserva.setVoo(reserva.new Voo(10)); // Cria uma instância de Voo dentro de ReservaPassagens
        return reserva;
    }
}
