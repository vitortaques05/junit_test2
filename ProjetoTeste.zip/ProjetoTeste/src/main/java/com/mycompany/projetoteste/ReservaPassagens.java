package com.mycompany.projetoteste;

import java.util.Date;

public class ReservaPassagens {

    private String origem;
    private String destino;
    private Date data;
    private int numPassageiros;
    private Voo voo;
    private boolean checkInRealizado;

    // Construtor
    public ReservaPassagens(String origem, String destino, Date data, int numPassageiros, Voo voo) {
        this.origem = origem;
        this.destino = destino;
        this.data = data;
        this.numPassageiros = numPassageiros;
        this.voo = voo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public int getNumPassageiros() {
        return numPassageiros;
    }

    public void setNumPassageiros(int numPassageiros) {
        this.numPassageiros = numPassageiros;
    }

    public Voo getVoo() {
        return voo;
    }

    public void setVoo(Voo voo) {
        this.voo = voo;
    }

    public void cancelarReserva() {
        // Libera os assentos reservados
        voo.liberarAssentos(numPassageiros);
        System.out.println("Reserva cancelada com sucesso.");
    }

    public boolean isCheckInRealizado() {
        // Verifica se o check-in já foi realizado
        if (!checkInRealizado) {
            System.out.println("Check-in realizado com sucesso.");
            checkInRealizado = true;
            return true;
        } else {
            System.out.println("Check-in já foi realizado anteriormente.");
            return false;
        }
    }

    public void realizaReserva(ReservaPassagens reserva) {
        //

        if (voo.verificarDisponibilidade(reserva.getNumPassageiros())) {
            // Reserva os assentos no voo
            voo.reservarAssentos(reserva.getNumPassageiros());

            // Imprime os detalhes da reserva
            System.out.println("Reserva realizada com sucesso para " + reserva.getNumPassageiros()
                    + " passageiros de " + reserva.getOrigem() + " para " + reserva.getDestino()
                    + " na data " + reserva.getData() + " no voo " + reserva.getVoo());

          

        } else {
            System.out.println("Desculpe, não há assentos disponíveis para a reserva.");
        }
    }
    
 

    class Voo {

        private int assentosDisponiveis;

        
        public Voo(int totalAssentos) {
            this.assentosDisponiveis = totalAssentos;
        }

        public int getAssentosDisponiveis() {
            return assentosDisponiveis;
        }

        public void setAssentosDisponiveis(int assentosDisponiveis) {
            this.assentosDisponiveis = assentosDisponiveis;
        }
        
        

        public boolean verificarDisponibilidade(int numAssentos) {
            return assentosDisponiveis >= numAssentos;
        }

        public void reservarAssentos(int numAssentos) {
            assentosDisponiveis -= numAssentos;
            System.out.println("Reserva realizada com sucesso.");
        }

        public void liberarAssentos(int numAssentos) {
            assentosDisponiveis += numAssentos;
            System.out.println("Assentos liberados com sucesso.");
        }
    }
}
